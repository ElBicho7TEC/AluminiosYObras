<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class bienvenida extends Model
{
    //
    public $timestamps = false;
    protected $table ='bienvenida';
    protected $primaryKey='idbienvenidos';
}
