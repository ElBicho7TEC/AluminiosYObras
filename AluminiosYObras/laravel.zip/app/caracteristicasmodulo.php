<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class caracteristicasmodulo extends Model
{
    //
    public $timestamps = false;
    protected $table ='caracteristicasmodulo';
    protected $primaryKey='idcaracteristicasmodulo';
}
