<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class carrusel extends Model
{
    //
    public $timestamps = false;
    protected $table ='carrusel';
    protected $primaryKey='idcarrusel';
}
